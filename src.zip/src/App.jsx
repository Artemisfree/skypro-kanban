import React, { useState } from 'react'
import './App.css'
import { cards as initialCards } from './data'
import PopExit from './components/PopExit/PopExit'
import Header from './components/Header/Header'
import PopNewCard from './components/PopNewCard/PopNewCard'
import PopBrowse from './components/PopBrowse/PopBrowse'
import Main from './components/Main/Main'

function App() {
	const [cards, setCards] = useState(initialCards)

  function onCardAdd() {
		const newCard = {
			id: cards.length + 1, // Простое присвоение нового ID
			topic: 'Copywriting',
			title: 'Название задачи',
			date: new Date().toLocaleDateString(),
			status: 'Без статуса',
		}
		setCards([...cards, newCard]) // Добавляем карточку в список
	}

	return (
		<div className='wrapper'>
			{/* pop-up start */}
			<PopExit />
			<PopNewCard />
			<PopBrowse />
			{/* pop-up end */}
			<Header onCardAdd={onCardAdd} />
			<Main cards={cards} />
		</div>
	)
}

export default App
